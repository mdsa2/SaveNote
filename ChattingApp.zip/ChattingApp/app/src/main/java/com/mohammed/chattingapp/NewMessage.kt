package com.mohammed.chattingapp

import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

import com.mohammed.chattingapp.adapter.myAdapter
import com.mohammed.chattingapp.databinding.ActivityNewMessageBinding


class NewMessage : ReqisterActivity() {
    private lateinit var adapter: myAdapter
  private  lateinit var userList :ArrayList<user>
    private lateinit var mAuth:FirebaseAuth
    lateinit var binding: ActivityNewMessageBinding
    private lateinit var mDbref:DatabaseReference
 var users:ArrayList<user>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityNewMessageBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)

        setContentView(binding.root)
        supportActionBar?.title = "Select User"
userList= ArrayList()
        adapter=  myAdapter(userList)
        binding.recyclerView.adapter = adapter

mAuth =FirebaseAuth.getInstance()
        mDbref=FirebaseDatabase.getInstance().getReference()
        binding.recyclerView.layoutManager = LinearLayoutManager(this)

mDbref.child("users").addValueEventListener(object :ValueEventListener{
    override fun onDataChange(snapshot: DataSnapshot) {

userList.clear()
     val user:user?=snapshot.getValue(user::class.java)

userList.add(user!!)


        adapter.notifyDataSetChanged()
     }





    override fun onCancelled(error: DatabaseError) {

    }

})
    }


    }

package com.mohammed.chattingapp.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

import com.mohammed.chattingapp.databinding.UserRowItemBinding
import com.mohammed.chattingapp.user


class myAdapter(val userList: ArrayList<user>): RecyclerView.Adapter<myAdapter.MyViewHolder>() {
    class MyViewHolder(val binding:UserRowItemBinding):RecyclerView.ViewHolder(binding.root) {

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
return MyViewHolder(UserRowItemBinding.inflate(LayoutInflater.from(parent.context),parent,false))
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
val currentuser = userList[position]

      
    }

    override fun getItemCount(): Int {
        return userList.size


     }
}
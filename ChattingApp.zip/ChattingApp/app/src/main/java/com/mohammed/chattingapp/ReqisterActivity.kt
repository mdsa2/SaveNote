package com.mohammed.chattingapp

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.view.WindowManager
import androidx.core.content.ContextCompat
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.StorageReference
import com.mohammed.chattingapp.databinding.ActivityReqisterBinding
import com.theartofdev.edmodo.cropper.CropImage
import com.theartofdev.edmodo.cropper.CropImageView
import java.util.jar.Manifest

open class ReqisterActivity : BaseActivity() {
    private lateinit var binding:ActivityReqisterBinding

    private lateinit var databaserefrence:DatabaseReference
    private lateinit var storagref:StorageReference
private lateinit var firebaseauth:FirebaseAuth
    private var imageuri: Uri? = null
private lateinit var images:String
    lateinit var username:String
    lateinit var email:String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReqisterBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        binding.dwaw.setOnClickListener {
            registerUser()
            saveuserToFirebaseDatabase(username,email ,imageuri!!)


        }
    }
    private fun validateRegisterDetalis():  Boolean  {
        return when {
            TextUtils.isEmpty(binding.nameReg.text.toString().trim { it <= ' ' }) -> {
                showErrorSnackBar(resources.getString(R.string.err_msg_enter_first_name), true)
                false
            }
            TextUtils.isEmpty(binding.Email.text.toString().trim { it <= ' ' }) -> {
                showErrorSnackBar(resources.getString(R.string.err_msg_enter_email), true)
                false

            }
            TextUtils.isEmpty(binding.password1.text.toString().trim { it <= ' ' }) -> {
                showErrorSnackBar(resources.getString(R.string.err_msg_enter_password), true)
                false


            }
            TextUtils.isEmpty(binding.password2.text.toString().trim { it <= ' ' }) -> {
                showErrorSnackBar(resources.getString(R.string.err_msg_enter_confirm_password), true)
                false


            }
            binding.password1.text.toString().trim{it<= ' '}   !=binding.password2.text.toString().trim{it<= ' '}  -> {
                showErrorSnackBar(resources.getString(R.string.err_msg_password_and_confirm_password_mismatch), true)
                false


            }





            binding.aq.isChecked -> {

                showErrorSnackBar(resources.getString(R.string.registery_succefull),false)
                true

            }else ->{

                showErrorSnackBar(resources.getString(R.string.err_msg_agree_terms_and_condation), true)
                false


            }







        }
    }

    private fun registerUser( ) {

        if (validateRegisterDetalis()) {
            showProgressDialog(resources.getString(R.string.please_wait))
            val email = binding.Email.text.toString().trim { it <= ' ' }
            val password = binding.password1.text.toString().trim { it <= ' ' }
            FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(
                    OnCompleteListener<AuthResult> { task ->
                        hideProgressDialog()
                        if (task.isSuccessful) {

                            val firebaseUser: FirebaseUser = task.result!!.user!!


                            showErrorSnackBar(

                                "you are registerd successfully.your user id is ${firebaseUser.uid}",
                                false

                            )


                            val intent = Intent(this, profile::class.java)
                            startActivity(intent)



                        } else {
                            showErrorSnackBar(task.exception!!.message.toString(), true)
                        }
                    })


        }

    }
    fun saveuserToFirebaseDatabase(username:String,email:String,imageuri:Uri)=kotlin.run{
      val uid=  FirebaseAuth.getInstance().uid ?: ""
val ref  = FirebaseDatabase.getInstance().getReference("/users/$uid")
        val user = user(uid,binding.nameReg.text.toString(),binding.Email.text.toString())
        storagref!!.child(firebaseauth .uid + AppCon.PATH).putFile(imageuri)
            .addOnSuccessListener {
                val task = it.storage.downloadUrl
                task.addOnCompleteListener { uri->
                    images=uri.result.toString()
                    val map = mapOf(
                        "username" to username,
                    "email" to email,
                    "image" to images,

                    )

                    databaserefrence!!.child(firebaseauth!!.uid!!).updateChildren(map)


                     }
            }


    }




}

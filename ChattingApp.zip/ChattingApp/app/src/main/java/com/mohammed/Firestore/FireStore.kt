package com.mohammed.Firestore

import android.media.session.MediaSessionManager
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.auth.User
import com.mohammed.chattingapp.BaseActivity
import com.mohammed.chattingapp.R
import com.mohammed.chattingapp.ReqisterActivity


class FireStore {
  //  private val mFiresore = FirebaseFirestore.getInstance()
   // fun reqisterUser( activity: ReqisterActivity ,  userInfo: Users) {
       // mFiresore.collection("users")
           // .document(userInfo.uid)
            //.set(userInfo, SetOptions.merge())
            //.addOnSuccessListener {
                class MyViewHolder(view: View) : RecyclerView.ViewHolder(view) {

                    init {
                        view.setOnClickListener {
                            Toast.makeText(view.context, "Sucessfuly reqister", Toast.LENGTH_SHORT)
                                .show()
                        }
                    }
                }
            }



package com.mohammed.chattingapp

import android.app.Activity
import android.content.ContentValues.TAG
import android.content.Intent

import android.graphics.drawable.BitmapDrawable
import android.net.Uri

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference

import com.mohammed.chattingapp.databinding.ActivityProfileBinding
import com.mohammed.chattingapp.databinding.ActivityReqisterBinding
import com.theartofdev.edmodo.cropper.CropImage
import com.theartofdev.edmodo.cropper.CropImageView
import java.util.*

@Suppress("DEPRECATION")
  class profile : ReqisterActivity() {

    private var imageuri: Uri? = null
    private lateinit var binding: ActivityProfileBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityProfileBinding.inflate(layoutInflater)

        setContentView(binding.root)

        binding.btnImage.setOnClickListener {

            val intent = Intent(Intent.ACTION_PICK)
            intent.type = "image/*"
            startActivityForResult(intent, 0)

            UploadImageTocload()
        }


    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        pickImage()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when(requestCode){
            CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE->{
                val result = CropImage.getActivityResult(data)

                    imageuri= result.uri
                    binding.selectcirt.setImageURI(imageuri)

            }
        }
    }

    private fun pickImage() {
        CropImage.activity()
            .setCropShape(CropImageView.CropShape.OVAL)
            .start(this)
    }

    fun UploadImageTocload() {
        if (imageuri == null)   return
            val filename = UUID.randomUUID().toString()
            val ref = FirebaseStorage.getInstance().getReference("/images/$filename")
            ref.putFile(imageuri!!)
                .addOnSuccessListener {
                    Log.d("RegisterActivity", "Succesful upload image${it.metadata?.path}")

                }
            ref.downloadUrl.addOnSuccessListener {
                Log.d("RegisterActivity", "File Location : $it")
                saveuserToFirebaseDatabase(username, email, imageuri!!)
            }





        }

        }






package com.mohammed.chattingapp

open class user(val uid: String, val username:String, val emailedt:String){

         constructor() : this("","","")




 }


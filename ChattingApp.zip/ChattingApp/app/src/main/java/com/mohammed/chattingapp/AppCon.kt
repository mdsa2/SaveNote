package com.mohammed.chattingapp

interface AppCon {
    companion object{
        val PATH ="profileImage/Image"
    }
}